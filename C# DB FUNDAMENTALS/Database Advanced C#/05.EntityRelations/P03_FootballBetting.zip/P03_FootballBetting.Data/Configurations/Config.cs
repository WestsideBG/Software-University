﻿namespace P03_FootballBetting.Data.Configurations
{
    public class Config
    {
        public const string ConnectionString = "Server=.;Database=FootballBettingSystemDB;Integrated Security=True";
    }
}