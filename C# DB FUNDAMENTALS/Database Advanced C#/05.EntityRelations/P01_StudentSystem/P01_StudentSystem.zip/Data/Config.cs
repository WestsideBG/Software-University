﻿namespace P01_StudentSystem.Data
{
    public class Config
    {
        public const string ConnectionString = "Server=.;Database=StudentDB;Integrated Security=True";
    }
}
