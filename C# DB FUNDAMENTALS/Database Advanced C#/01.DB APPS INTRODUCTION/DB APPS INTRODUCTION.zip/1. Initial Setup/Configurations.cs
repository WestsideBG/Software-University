﻿namespace _1._Initial_Setup
{
    public class Configurations
    {
        public const string ConnectionString = "Server=.;Database=MinionsDB;Integrated security=True";
    }
}
