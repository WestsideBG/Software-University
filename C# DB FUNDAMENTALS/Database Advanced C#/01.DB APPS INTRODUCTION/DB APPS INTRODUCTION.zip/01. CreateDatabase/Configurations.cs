﻿namespace _01._CreateDatabase
{
    public class Configurations
    {
        public const string ConnectionString = "Server=.;;Integrated security=True";
    }
}
