﻿using System.Xml;
using System.Xml.Serialization;

namespace ProductShop.Dtos.Export
{
    public class SoldProductWithCountDto
    {
        [XmlElement("count")]
        public int Count { get; set; }

        [XmlArray("products")]
        public SoldProductDto[] SoldProducts { get; set; }
    }
}