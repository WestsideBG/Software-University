﻿using System.Xml.Serialization;

namespace ProductShop.Dtos.Export
{
    public class ExportUsersWithProductsDto
    {
        [XmlElement("count")]
        public int Count { get; set; }

        [XmlArray("users")]
        public UserDto[] Users { get; set; }
    }
}