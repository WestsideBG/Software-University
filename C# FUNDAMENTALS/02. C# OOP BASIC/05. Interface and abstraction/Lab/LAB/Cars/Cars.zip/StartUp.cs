﻿using Cars.Core;

namespace Cars
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Enginе engine = new Enginе();

            engine.Run();
        }
    }
}
