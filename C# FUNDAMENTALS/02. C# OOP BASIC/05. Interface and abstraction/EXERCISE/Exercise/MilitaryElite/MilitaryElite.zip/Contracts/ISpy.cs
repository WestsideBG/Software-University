﻿namespace MilitaryElite.Contracts
{
    public interface ISpy : ISolder
    {
        int CodeNumber { get; }
    }
}
