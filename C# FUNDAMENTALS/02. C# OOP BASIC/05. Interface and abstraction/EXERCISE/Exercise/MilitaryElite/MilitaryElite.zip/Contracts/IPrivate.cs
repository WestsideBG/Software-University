﻿namespace MilitaryElite.Contracts
{
    public interface IPrivate : ISolder
    {
        decimal Salary { get; }
    }
}
