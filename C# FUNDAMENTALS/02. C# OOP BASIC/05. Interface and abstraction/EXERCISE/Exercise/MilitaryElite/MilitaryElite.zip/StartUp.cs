﻿using System;
using MilitaryElite.Core;

namespace MilitaryElite
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
