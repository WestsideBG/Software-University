﻿namespace Telephony
{
    public interface ICall
    {
        string Calling(string number);
    }
}
