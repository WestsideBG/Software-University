﻿namespace BorderControl
{
    public interface IRobot
    {
        string Model { get; }
        string Id { get; }
    }
}
