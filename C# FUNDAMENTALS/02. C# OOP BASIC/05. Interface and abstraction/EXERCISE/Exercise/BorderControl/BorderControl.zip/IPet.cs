﻿namespace BorderControl
{
    public interface IPet
    {
        string Name { get; }
        string Birthdate { get; }

    }
}
