﻿namespace WildFarm.Foods
{
    public interface IFood
    {
        int Quantity { get; }
    }
}