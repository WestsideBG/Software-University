﻿namespace WildFarm.Animals.Birds
{
    public interface IBird : IAnimal
    {
        double WingSize { get; }
    }
}