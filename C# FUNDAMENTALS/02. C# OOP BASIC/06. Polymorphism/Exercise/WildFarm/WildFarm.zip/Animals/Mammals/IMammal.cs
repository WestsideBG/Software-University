﻿namespace WildFarm.Animals.Mammals
{
    public interface IMammal : IAnimal
    {
        string LivingRegion { get; }
    }
}