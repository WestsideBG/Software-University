﻿namespace Farm
{
    public abstract class Animal
    {
        public void Eat()
        {
            System.Console.WriteLine("eating...");
        }
    }
}
