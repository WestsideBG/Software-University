﻿namespace SOLIDLogger.Loggers.enums
{
    public enum ReportLevel
    {
        INFO = 1,
        WARNING = 2,
        ERROR = 3,
        CRITICAL = 4,
        FATAL = 5
    }
}