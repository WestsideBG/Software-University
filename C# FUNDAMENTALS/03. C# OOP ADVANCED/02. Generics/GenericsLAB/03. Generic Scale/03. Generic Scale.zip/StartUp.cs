﻿namespace GenericScale
{
    public class StartUp
    {
         static void Main()
        {
            var scale = new Scale<int>(9,5);

            var result = scale.GetHeavier();
        }
    }
}
